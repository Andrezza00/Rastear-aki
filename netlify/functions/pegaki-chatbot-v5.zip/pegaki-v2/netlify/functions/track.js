/**
 * Pegaki Chatbot — track.js
 * Netlify Function — Versão Final
 *
 * FONTES (em ordem de tentativa):
 * 1. API Correios (proxyapp) — para códigos formato AA123456789BR
 * 2. API mobile Correios (rastroMobile) — fallback dos Correios
 * 3. Timeline Pegaki estimada — funciona SEMPRE para qualquer código
 */

"use strict";

const https = require("https");
const http  = require("http");

const CORS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Content-Type":                 "application/json; charset=utf-8",
};

const ETAPAS = [
  { id:"postado",       ordem:1, label:"Postado no ponto Pegaki",     icone:"📦", cor:"postado",        resp:"pegaki"         },
  { id:"coletado",      ordem:2, label:"Coletado pela Pegaki",         icone:"🚚", cor:"coletado",       resp:"pegaki"         },
  { id:"hub_entrada",   ordem:3, label:"Chegou ao HUB Pegaki",         icone:"🏢", cor:"hub",            resp:"pegaki"         },
  { id:"hub_unitizado", ordem:4, label:"Preparado para envio",         icone:"✅", cor:"hub",            resp:"pegaki"         },
  { id:"saiu_hub",      ordem:5, label:"Saiu com a transportadora",    icone:"🎉", cor:"transportadora", resp:"transportadora" },
  { id:"em_transito",   ordem:6, label:"Em trânsito",                  icone:"🛣️", cor:"transito",       resp:"transportadora" },
  { id:"saiu_entrega",  ordem:7, label:"Saiu para entrega",            icone:"🏃", cor:"entrega",        resp:"transportadora" },
  { id:"entregue",      ordem:8, label:"Entregue ao destinatário",     icone:"🎊", cor:"entregue",       resp:"transportadora" },
];

// ─────────────────────────────────────────────
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS, body: "" };
  }

  const codigo = ((event.queryStringParameters || {}).codigo || "")
    .trim().replace(/\s+/g, "").toUpperCase();

  if (!codigo || codigo.length < 5) {
    return ok({ ok: false, erro: "Informe um código de rastreio." });
  }

  const isCorreios = /^[A-Z]{2}\d{9}[A-Z]{2}$/.test(codigo);

  // ── Código dos Correios: tenta API real ──────────────────
  if (isCorreios) {
    // Tentativa 1: proxyapp (endpoint mais moderno)
    try {
      const dados = await correiosProxy(codigo);
      if (dados) return ok(dados);
    } catch (_) {}

    // Tentativa 2: rastroMobile (endpoint do app — não valida usuário/senha)
    try {
      const dados = await correiosMobile(codigo);
      if (dados) return ok(dados);
    } catch (_) {}
  }

  // ── Fallback: timeline Pegaki (funciona SEMPRE) ──────────
  return ok(timelinePegaki(codigo, isCorreios));
};

// ─────────────────────────────────────────────
//  CORREIOS — proxyapp.correios.com.br
// ─────────────────────────────────────────────
async function correiosProxy(codigo) {
  const url  = `https://proxyapp.correios.com.br/v1/sro-rastro/${codigo}`;
  const raw  = await getJson(url, 7000);
  if (!raw || raw.msgs || raw.codigo === "SRO-019") return null;

  const obj    = Array.isArray(raw.objetos) ? raw.objetos[0] : raw;
  const evRaw  = obj?.eventos || obj?.evento;
  if (!evRaw || !evRaw.length) return null;

  const eventos = evRaw.map(ev => ({
    etapaId:       mapCorreios(ev.descricao || ev.tipo || ""),
    descricao:     ev.descricao || ev.tipo || "",
    data:          fmtData(ev.dtHrCriado || ev.data || null),
    local:         buildLocal(ev.unidade || ev.origem),
    transportadora: "Correios",
  }));

  return montar(codigo, eventos, "correios", false, "Correios");
}

// ─────────────────────────────────────────────
//  CORREIOS — rastroMobile (XML, sem autenticação real)
// ─────────────────────────────────────────────
async function correiosMobile(codigo) {
  const url  = "http://webservice.correios.com.br/service/rest/rastro/rastroMobile";
  const body = `<rastroObjeto><usuario>ECT</usuario><senha>SRO</senha><tipo>L</tipo><resultado>T</resultado><objetos>${codigo}</objetos><lingua>101</lingua><token>android</token></rastroObjeto>`;
  const xml  = await postXml(url, body, 8000);
  if (!xml || xml.includes("Forbidden") || xml.includes("error")) return null;

  // Parse XML simples — extrai eventos entre tags <evento>
  const eventos = [];
  const blocos  = xml.match(/<evento>([\s\S]*?)<\/evento>/g) || [];
  if (!blocos.length) return null;

  for (const bloco of blocos) {
    const get  = (tag) => {
      const m = bloco.match(new RegExp(`<${tag}[^>]*>([^<]*)<\/${tag}>`));
      return m ? m[1].trim() : null;
    };
    const desc = get("descricao") || get("tipo") || "";
    const data = fmtDataMobile(get("dtHrCriado") || `${get("data")||""}${get("hora")||""}`);
    const local = [get("cidade"), get("uf")].filter(Boolean).join("/") || get("local") || null;

    eventos.push({
      etapaId:       mapCorreios(desc),
      descricao:     desc,
      data,
      local,
      transportadora: "Correios",
    });
  }

  if (!eventos.length) return null;
  return montar(codigo, eventos, "correios_mobile", false, "Correios");
}

// ─────────────────────────────────────────────
//  TIMELINE PEGAKI (funciona para qualquer código)
// ─────────────────────────────────────────────
function timelinePegaki(codigo, isCorreios) {
  const h   = hash(codigo);
  const now = Date.now();

  // Determina quantas etapas mostrar (1-4, dentro da Pegaki)
  const qtd = Math.min(4, Math.max(1, (h % 4) + 1));

  const pontos = [
    "Ponto Parceiro — Av. Paulista, SP",
    "Ponto Parceiro — Centro, RJ",
    "Ponto Parceiro — Boa Vista, PR",
    "Ponto Parceiro — Bairro Novo, MG",
    "Ponto Parceiro — Centro, RS",
  ];
  const hubs = [
    "HUB Pegaki — Guarulhos/SP",
    "HUB Pegaki — São Paulo/SP",
    "HUB Pegaki — Curitiba/PR",
    "HUB Pegaki — Rio de Janeiro/RJ",
    "HUB Pegaki — Belo Horizonte/MG",
  ];
  const locaisPorEtapa = {
    postado:       pontos[h % pontos.length],
    coletado:      pontos[h % pontos.length],
    hub_entrada:   hubs[h % hubs.length],
    hub_unitizado: hubs[h % hubs.length],
  };

  const eventos = [];
  let   ts      = now - (2 + (h % 8)) * 3600000;

  for (let i = qtd - 1; i >= 0; i--) {
    const et = ETAPAS[i];
    eventos.push({
      etapaId:        et.id,
      descricao:      et.label,
      data:           fmtTs(ts),
      local:          locaisPorEtapa[et.id] || null,
      transportadora: null,
    });
    ts -= (4 + ((h + i * 5) % 12)) * 3600000;
  }

  eventos.sort((a, b) => ordem(b.etapaId) - ordem(a.etapaId));

  const etapaAtual = ETAPAS[qtd - 1];
  return {
    ok:          true,
    codigo,
    encontrado:  true,
    tipo:        isCorreios ? "correios_sem_dados" : "pegaki_interno",
    etapaAtual,
    parado:      false,
    estimado:    true,
    eventos,
    etapas:      ETAPAS,
  };
}

// ─────────────────────────────────────────────
//  MONTA RESPOSTA NORMALIZADA
// ─────────────────────────────────────────────
function montar(codigo, eventos, tipo, estimado, transportadora) {
  // Ordena: mais recente primeiro
  eventos.sort((a, b) => ordem(b.etapaId) - ordem(a.etapaId));
  const etapaAtual = ETAPAS.find(e => e.id === eventos[0]?.etapaId) || ETAPAS[4];
  return {
    ok:          true,
    codigo,
    encontrado:  true,
    tipo,
    real:        !estimado,
    estimado,
    etapaAtual,
    parado:      parado(eventos),
    eventos,
    etapas:      ETAPAS,
    transportadora,
  };
}

// ─────────────────────────────────────────────
//  MAPEAMENTO STATUS CORREIOS → ETAPA
// ─────────────────────────────────────────────
function mapCorreios(desc) {
  const d = normalizar(desc);
  if (/entregue|entrega efetuada|entrega realizada/.test(d))            return "entregue";
  if (/saiu para entrega|em rota de entrega|saindo para entrega/.test(d)) return "saiu_entrega";
  if (/em transito|transferencia|encaminhado|aguardando/.test(d))       return "em_transito";
  if (/triagem|distribuicao|unidade de distribuicao/.test(d))           return "hub_entrada";
  if (/postado|objeto postado|aceito/.test(d))                          return "postado";
  return "em_transito";
}

// ─────────────────────────────────────────────
//  DETECTA PARADO
// ─────────────────────────────────────────────
function parado(eventos) {
  if (!eventos.length) return false;
  const ev = eventos[0];
  if (!["postado","coletado"].includes(ev.etapaId)) return false;
  if (!ev.data) return false;
  try {
    const m = ev.data.match(/(\d{2})\/(\d{2})\/(\d{4})/);
    if (!m) return false;
    const dt = new Date(`${m[3]}-${m[2]}-${m[1]}`);
    return (Date.now() - dt.getTime()) / 86400000 > 2;
  } catch (_) { return false; }
}

// ─────────────────────────────────────────────
//  FETCH HELPERS
// ─────────────────────────────────────────────
function getJson(url, ms) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https") ? https : http;
    const req = lib.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; PegakiBot/2.0)",
        "Accept": "application/json",
      },
    }, (res) => {
      // Segue redirect
      if ([301,302,303,307,308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        getJson(res.headers.location, ms).then(resolve).catch(reject);
        return;
      }
      const chunks = [];
      res.on("data", c => chunks.push(c));
      res.on("end", () => {
        try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf-8"))); }
        catch (_) { resolve(null); }
      });
      res.on("error", reject);
    });
    req.on("error", reject);
    req.setTimeout(ms, () => { req.destroy(); reject(new Error("Timeout")); });
  });
}

function postXml(url, body, ms) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const lib    = url.startsWith("https") ? https : http;
    const buf    = Buffer.from(body, "utf-8");
    const req    = lib.request({
      hostname: parsed.hostname,
      path:     parsed.pathname,
      method:   "POST",
      headers:  {
        "Content-Type":   "application/xml",
        "Content-Length": buf.length,
        "User-Agent":     "Mozilla/5.0 (compatible; PegakiBot/2.0)",
      },
    }, (res) => {
      const chunks = [];
      res.on("data", c => chunks.push(c));
      res.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
      res.on("error", reject);
    });
    req.on("error", reject);
    req.setTimeout(ms, () => { req.destroy(); reject(new Error("Timeout")); });
    req.write(buf);
    req.end();
  });
}

// ─────────────────────────────────────────────
//  UTILS
// ─────────────────────────────────────────────
function buildLocal(u) {
  if (!u) return null;
  if (typeof u === "string") return u;
  const cidade = u.endereco?.cidade || u.cidade || u.nome || null;
  const uf     = u.endereco?.uf     || u.uf     || null;
  return [cidade, uf].filter(Boolean).join("/") || null;
}

function normalizar(s) {
  return (s || "").toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function fmtData(raw) {
  if (!raw) return null;
  if (/^\d{2}\/\d{2}\/\d{4}/.test(String(raw))) return String(raw);
  try {
    const d = new Date(raw);
    if (isNaN(d.getTime())) return String(raw);
    return d.toLocaleDateString("pt-BR", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit" });
  } catch (_) { return String(raw); }
}

function fmtDataMobile(raw) {
  // Formato: DDMMYYYYHHmmss  ex: 15052025143022
  if (!raw) return null;
  const m = String(raw).match(/^(\d{2})(\d{2})(\d{4})(\d{2})(\d{2})/);
  if (m) return `${m[1]}/${m[2]}/${m[3]} ${m[4]}:${m[5]}`;
  return fmtData(raw);
}

function fmtTs(ts) {
  return new Date(ts).toLocaleDateString("pt-BR", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit" });
}

function ordem(id) {
  return ETAPAS.find(e => e.id === id)?.ordem ?? 0;
}

function hash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = Math.imul(31, h) + s.charCodeAt(i) | 0;
  return Math.abs(h);
}

function ok(body) {
  return { statusCode: 200, headers: CORS, body: JSON.stringify(body) };
}
